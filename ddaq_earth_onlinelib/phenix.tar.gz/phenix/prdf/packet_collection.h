

#include "packet_id4evt.h"
#include "packet_id2evt.h"
#include "packet_idcstr.h"


#include "packet_gl1.h"
#include "packet_gl1p.h"
#include "packet_gl1psum.h"
#include "packet_gl1_evclocks.h"

#include "packet_id4scaler.h"
#include "packet_iddigitizerv2.h"

#include "packet_cdevpolarimeter.h"
#include "packet_cdevir.h"
#include "packet_cdevwcm.h"
#include "packet_cdevbpm.h"
#include "packet_cdevmadch.h"
#include "packet_cdevring.h"
#include "packet_cdevdvm.h"
#include "packet_cdevpoltarget.h"
#include "packet_cdevbuckets.h"
#include "packet_cdevringnopol.h"
#include "packet_idcdevdescr.h"

#include "packet_starscaler.h"

#include "packet_hbd_fpga.h"
#include "packet_hbd_fpgashort.h"

#include "packet_fvtx_dcm0.h"
