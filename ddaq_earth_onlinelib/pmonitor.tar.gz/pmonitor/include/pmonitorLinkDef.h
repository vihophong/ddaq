#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;


#pragma link C++ function pclearidentify;
#pragma link C++ function pclose;
#pragma link C++ function pcontrol;
#pragma link C++ function pexitstatus;
#pragma link C++ function pfileopen;
#pragma link C++ function phelp;
#pragma link C++ function phsave;
#pragma link C++ function pidentify;
#pragma link C++ function plistopen;
#pragma link C++ function plock;
#pragma link C++ function poncsopen;
#pragma link C++ function rcdaqopen;
#pragma link C++ function prelease;
#pragma link C++ function prun;
#pragma link C++ function pstart;
#pragma link C++ function pstatus;
#pragma link C++ function pstop;
#pragma link C++ function ptestopen;
#pragma link C++ function pwait;

#endif /* __CINT__ */
